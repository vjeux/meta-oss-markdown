---
title: "Requiring More Annotations to Functions and Classes in Flow"
short-title: "Functions and Classes Annotation Requirements"
author: "Sam Zhou"
medium-link: "https://medium.com/flow-type/requiring-more-annotations-to-functions-and-classes-in-flow-e8aa9b1d76bd"
---
Flow will now require more annotations to functions and classes.
