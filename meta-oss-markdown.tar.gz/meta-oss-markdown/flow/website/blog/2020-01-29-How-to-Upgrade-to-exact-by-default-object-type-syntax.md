---
title: "How to upgrade to exact-by-default object type syntax"
short-title: "Upgrade to exact-by-default"
author: "Jordan Brown"
medium-link: "https://medium.com/flow-type/how-to-upgrade-to-exact-by-default-object-type-syntax-7aa44b4d08ab"
---
Object types will become exact-by-default. Read this post to learn how to get your code ready!
