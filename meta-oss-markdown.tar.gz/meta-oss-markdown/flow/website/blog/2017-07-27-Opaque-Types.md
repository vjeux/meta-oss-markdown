---
title: "Opaque Type Aliases"
short-title: "Opaque Type Aliases"
author: "Jordan Brown"
medium-link: "https://medium.com/flow-type/hiding-implementation-details-with-flows-new-opaque-type-aliases-feature-40e188c2a3f9"
---
Do you ever wish that you could hide your implementation details away
from your users? Find out how opaque type aliases can get the job done!
