---
title: "New Flow Language Rule: Constrained Writes"
short-title: "Introducing Constrained Writes"
author: "Jordan Brown"
medium-link: "https://medium.com/flow-type/new-flow-language-rule-constrained-writes-4c70e375d190"
---
Flow is releasing a new language rule that determines the type of an unannotated variable at its initialization. Along with these new rules come several fixes to soundness bugs that were causing refinements to not be invalidated.
