---
title: "Asking for Required Annotations"
short-title: "Asking for Required Annotations"
author: "Sam Goldman"
medium-link: "https://medium.com/flow-type/asking-for-required-annotations-64d4f9c1edf8"
---

Flow will be asking for more annotations starting in 0.85.0. Learn how
to deal with these errors in our latest blog post.
