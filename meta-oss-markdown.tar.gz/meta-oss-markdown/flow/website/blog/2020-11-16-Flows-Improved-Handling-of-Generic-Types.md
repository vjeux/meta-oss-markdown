---
title: "Flow's Improved Handling of Generic Types"
short-title: "Generic Types Improvements"
author: "Michael Vitousek"
medium-link: "https://medium.com/flow-type/flows-improved-handling-of-generic-types-b5909cc5e3c5"
---
Flow has improved its handling of generic types by banning unsafe behaviors previously allowed and clarifying error messages.
