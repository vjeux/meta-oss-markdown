---
title: "Types-First: A Scalable New Architecture for Flow"
short-title: "Types-First: A Scalable New"
author: "Panagiotis Vekris"
medium-link: "https://medium.com/flow-type/types-first-a-scalable-new-architecture-for-flow-3d8c7ba1d4eb"
---
Flow Types-First mode is out! It unlocks Flow’s potential at scale by leveraging fully typed module boundaries. Read more in our latest blog post.
