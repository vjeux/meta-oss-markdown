---
title: "TypeScript Enums vs. Flow Enums"
short-title: "TypeScript Enums vs. Flow Enums"
author: "George Zahariev"
medium-link: "https://medium.com/flow-type/typescript-enums-vs-flow-enums-83da2ca4a9b4"
---
A comparison of the enums features of TypeScript and Flow.
