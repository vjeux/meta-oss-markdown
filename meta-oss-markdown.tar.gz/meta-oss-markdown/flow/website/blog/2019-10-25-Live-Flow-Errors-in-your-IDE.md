---
title: "Live Flow errors in your IDE"
short-title: "Live Flow errors in your IDE"
author: "Gabe Levi"
medium-link: "https://medium.com/flow-type/live-flow-errors-in-your-ide-bcbeda0b316"
---
Live errors while you type makes Flow feel faster in your IDE!
