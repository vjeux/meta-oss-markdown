---
title: "Introducing Flow Indexed Access Types"
short-title: "Flow Indexed Access Types"
author: "George Zahariev"
medium-link: "https://medium.com/flow-type/introducing-flow-indexed-access-types-b27175251fd0"
---
Flow’s Indexed Access Types are a new type annotation syntax that allows you to get the type of a property from an object, array, or tuple type.
