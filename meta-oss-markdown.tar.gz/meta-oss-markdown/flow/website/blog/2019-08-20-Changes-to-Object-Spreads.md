---
title: "Coming Soon: Changes to Object Spreads"
short-title: "Changes to Object Spreads"
author: "Jordan Brown"
medium-link: "https://medium.com/flow-type/coming-soon-changes-to-object-spreads-73204aef84e1"
---
Changes are coming to how Flow models object spreads! Learn more in this post.
