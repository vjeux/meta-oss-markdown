---
title: "A More Responsive Flow"
short-title: "A More Responsive Flow"
author: "Gabe Levi"
medium-link: "https://medium.com/flow-type/a-more-responsive-flow-1a8cb01aec11"
---
Flow 0.92 improves on the Flow developer experience.
