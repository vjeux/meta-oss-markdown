---
title: "Exact object types by default, by default"
short-title: "Exact object types by default, by default"
author: "George Zahariev"
medium-link: "https://medium.com/flow-type/exact-object-types-by-default-by-default-cc559af6f69"
---
We announced 5 years ago a plan to eventually make exact object types the default. We are now proceeding with this plan.
