---
title: "Introducing: Local Type Inference for Flow"
short-title: "Introducing Local Type Inference"
author: "Michael Vitousek"
medium-link: "https://medium.com/flow-type/introducing-local-type-inference-for-flow-6af65b7830aa"
---
We're replacing Flow’s current inference engine with a system that behaves more predictably and can be reasoned about more locally.
