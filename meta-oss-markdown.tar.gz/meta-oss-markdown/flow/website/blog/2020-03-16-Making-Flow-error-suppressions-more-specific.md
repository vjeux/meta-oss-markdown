---
title: "Making Flow error suppressions more specific"
short-title: "Making Flow error suppressions"
author: "Daniel Sainati"
medium-link: "https://medium.com/flow-type/making-flow-error-suppressions-more-specific-280aa4e3c95c"
---
We’re improving Flow error suppressions so that they don’t accidentally hide errors.
