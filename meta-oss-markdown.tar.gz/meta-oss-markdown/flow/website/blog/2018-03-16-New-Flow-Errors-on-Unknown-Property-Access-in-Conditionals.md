---
title: "New Flow Errors on Unknown Property Access in Conditionals"
short-title: "Unknown Props in Conditionals"
author: "Gabe Levi"
medium-link: "https://medium.com/flow-type/new-flow-errors-on-unknown-property-access-in-conditionals-461da66ea10"
---
TL;DR: Starting in 0.68.0, Flow will now error when you access unknown
properties in conditionals.
