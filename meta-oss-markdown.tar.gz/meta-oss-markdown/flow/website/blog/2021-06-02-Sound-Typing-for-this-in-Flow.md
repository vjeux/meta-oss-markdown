---
title: "Sound Typing for 'this' in Flow"
short-title: "Sound Typing for 'this'"
author: "Daniel Sainati"
medium-link: "https://medium.com/flow-type/sound-typing-for-this-in-flow-d62db2af969e"
---
Improvements in soundness for `this`-typing in Flow, including the ability to annotate `this` on functions and methods.
