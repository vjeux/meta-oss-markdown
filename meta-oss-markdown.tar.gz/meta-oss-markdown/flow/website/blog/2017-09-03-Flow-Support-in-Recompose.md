---
title: "Typing Higher-Order Components in Recompose With Flow"
short-title: "Flow Support in Recompose"
author: "Ivan Starkov"
medium-link: "https://medium.com/flow-type/flow-support-in-recompose-1b76f58f4cfc"
---
One month ago [Recompose](https://github.com/acdlite/recompose) landed an
official Flow library definition. The definitions were a long time coming,
considering the original PR was created by
[@GiulioCanti](https://twitter.com/GiulioCanti) a year ago.
