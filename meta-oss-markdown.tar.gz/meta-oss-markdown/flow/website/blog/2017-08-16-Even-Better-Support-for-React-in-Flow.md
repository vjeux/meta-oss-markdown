---
title: "Even Better Support for React in Flow"
short-title: "Even Better React Support"
author: "Caleb Meredith"
medium-link: "https://medium.com/flow-type/even-better-support-for-react-in-flow-25b0a3485627"
---
The first version of Flow support for React was a magical implementation of
`React.createClass()`. Since then, React has evolved significantly. It is time
to rethink how Flow models React.
