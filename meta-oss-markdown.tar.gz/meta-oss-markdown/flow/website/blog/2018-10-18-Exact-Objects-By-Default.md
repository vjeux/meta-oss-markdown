---
title: "On the Roadmap: Exact Objects by Default"
short-title: "Exact Objects by Default"
author: "Jordan Brown"
medium-link: "https://medium.com/flow-type/on-the-roadmap-exact-objects-by-default-16b72933c5cf"
---
We are changing object types to be exact by default. We'll be releasing codemods to help you upgrade.
