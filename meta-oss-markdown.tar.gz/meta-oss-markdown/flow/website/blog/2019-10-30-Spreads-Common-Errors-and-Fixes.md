---
title: "Spreads: Common Errors & Fixes"
short-title: "Spreads: Common Errors & Fixes"
author: "Jordan Brown"
medium-link: "https://medium.com/flow-type/spreads-common-errors-fixes-9701012e9d58"
---
Fixes to object spreads will expose errors in your codebase. Read more about common errors and how to fix them.
