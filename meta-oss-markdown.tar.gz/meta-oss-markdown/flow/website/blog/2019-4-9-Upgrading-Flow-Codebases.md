---
title: "Upgrading Flow Codebases"
short-title: "Upgrading Flow Codebases"
author: "Jordan Brown"
medium-link: "https://medium.com/flow-type/upgrading-flow-codebases-40ef8dd3ccd8"
---
Having trouble upgrading from 0.84.0? Read about how the Flow team upgrades Flow at Facebook!
