---
title: "Types-First the only supported mode in Flow (Jan 2021)"
short-title: "Types-First only supported mode"
author: "Panagiotis Vekris"
medium-link: "https://medium.com/flow-type/types-first-the-only-supported-mode-in-flow-jan-2021-3c4cb14d7b6c"
---
Types-First will become the only mode in Flow in v0.143 (mid Jan 2021).
