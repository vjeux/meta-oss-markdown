---
title: "What we’re building in 2020"
short-title: "What we’re building in 2020"
author: "Andrew Pardoe"
medium-link: "https://medium.com/flow-type/what-were-building-in-2020-bcb92f620c75"
---
Learn about how Flow will improve in 2020. 
