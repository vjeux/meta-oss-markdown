---
title: "What the Flow Team Has Been Up To"
short-title: "What the Flow Team Has Been Up To"
author: "Avik Chaudhuri"
medium-link: "https://medium.com/flow-type/what-the-flow-team-has-been-up-to-54239c62004f"
---
Take a look at what the Flow was up to in 2018.
