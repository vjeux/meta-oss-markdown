---
title: "Supporting React.forwardRef and Beyond"
short-title: "Supporting React.forwardRef"
author: "Jordan Brown"
medium-link: "https://medium.com/flow-type/supporting-react-forwardref-and-beyond-f8dd88f35544"
---

We made some major changes to our React model to better model new React components. Let's
talk about React.AbstractComponent!
