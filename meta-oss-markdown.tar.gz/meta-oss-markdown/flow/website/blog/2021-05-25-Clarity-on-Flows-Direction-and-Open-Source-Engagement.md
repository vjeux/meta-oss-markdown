---
title: "Clarity on Flow's Direction and Open Source Engagement"
short-title: "Flow Direction Update"
author: "Vladan Djeric"
medium-link: "https://medium.com/flow-type/clarity-on-flows-direction-and-open-source-engagement-e721a4eb4d8b"
---
An update on Flow's direction and open source engagement.
