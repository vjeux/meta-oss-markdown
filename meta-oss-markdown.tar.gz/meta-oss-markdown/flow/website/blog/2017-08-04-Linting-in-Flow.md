---
title: "Linting in Flow"
short-title: "Linting in Flow"
author: "Roger Ballard"
medium-link: "https://medium.com/flow-type/linting-in-flow-7709d7a7e969"
---
Flow’s type information is useful for so much more than just proving your programs are correct. Introducing Flow linter.
