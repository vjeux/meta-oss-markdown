---
title: "Improvements to Flow in 2019"
short-title: "Improvements to Flow in 2019"
author: "Andrew Pardoe"
medium-link: "https://medium.com/flow-type/improvements-to-flow-in-2019-c8378e7aa007"
---
Take a look back at improvements we made to Flow in 2019.
