---
title: "Introducing Flow Enums"
short-title: "Introducing Flow Enums"
author: "George Zahariev"
medium-link: "https://medium.com/flow-type/introducing-flow-enums-16d4239b3180"
---
Flow Enums are an opt-in feature which allow you to define a fixed set of constants which create their own type.
