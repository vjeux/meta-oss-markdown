---
title: .flowconfig [lints]
slug: /config/lints
---

The `[lints]` section in a `.flowconfig` file can contain several key-value
pairs of the form:

```
[lints]
ruleA=severityA
ruleB=severityB
```

Check out the [linting docs](../../linting) for more information.
