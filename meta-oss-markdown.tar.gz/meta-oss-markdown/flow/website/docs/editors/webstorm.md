---
title: WebStorm
slug: /editors/webstorm
---

Webstorm installation instructions can be found here:
- [WebStorm 2016.3](https://www.jetbrains.com/help/webstorm/2016.3/using-the-flow-type-checker.html)
- [WebStorm 2017.1](https://www.jetbrains.com/help/webstorm/2017.1/flow-type-checker.html)
