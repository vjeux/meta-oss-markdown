# 0.0.4
- Update README documentation

# 0.0.3
- Exported the rules added in 0.0.2 from `index.js`

# 0.0.2
- Added rule `use-exact-by-default-object-type`
- Added rule `use-flow-enums`
- Added rule `flow-enums-default-if-possible`
- Added rule `no-flow-enums-object-mapping`

# 0.0.1
- Initial version
- Added rule `use-indexed-access-type`
