---
name: "Library Definitions"
about: You want to report an issue with Flow's library definitions.
labels: "Library definitions"
---

<!--
Please fill out this entire template so that we can address your report as quickly as possible.
-->

<!--
Explain what APIs are not modeled by Flow or could be improved
-->
## Missing/Incorrect APIs

<!--
Please include documentation for the missing APIs.
-->
## Relevant documentation
