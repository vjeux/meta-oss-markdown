---
name: "Discussion"
about: You want to propose a change to Flow.
labels: "discussion"
---

<!--
Please fill out this entire template so that we can evaluate your proposal as quickly as possible.
-->

## Proposal

<!--
  Explain why you need this change and why this cannot be addressed with Flow's current set of features.
-->
## Use case
