:::info

The TypeScript examples from this page will only work as documented if you explicitly import Jest APIs:

```ts
import {expect, jest, test} from '@jest/globals';
```

Consult the [Getting Started](GettingStarted.md#using-typescript) guide for details on how to setup Jest with TypeScript.

:::
